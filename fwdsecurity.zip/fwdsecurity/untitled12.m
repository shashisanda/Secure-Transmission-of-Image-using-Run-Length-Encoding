clc
clear all
close all
I=imread('lena_gray.bmp');
w=zigzag(I);
y=im2huff(w);
x=huff2im(y);
w=invzigzag(x);