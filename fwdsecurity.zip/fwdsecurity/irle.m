function XZv=irle(t)
 L=length(t);
 u=1;
 k=1;
 i=1;
 while i<=L
    while u<=t(i+1)
        XZv(k)=t(i);
        u=u+1;
        k=k+1;
    end;
    i=i+2;
    u=1;
 end;
