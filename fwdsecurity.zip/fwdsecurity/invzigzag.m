function w=invzigzag(v)
row=round(sqrt(length(v)));
w=zeros(row,row);
count=1;
for s=1:row
    if mod(s,2)==0
        for m=s:-1:1
            w(m,s+1-m)=v(count);
            count=count+1;
        end;
    else
        for m=1:s
            w(m,s+1-m)=v(count);
            count=count+1;
        end;
    end;
end;
if mod(row,2)==0
    flip=1;
else
    flip=0;
end;
for s=row+1:2*row-1
    if mod(flip,2)==0
        for m=row:-1:s+1-row
            w(m,s+1-m)=v(count);
            count=count+1;
        end;
    else
        for m=row:-1:s+1-row
            w(s+1-m,m)=v(count);
            count=count+1;
        end;
    end
    flip=flip+1;
end;
