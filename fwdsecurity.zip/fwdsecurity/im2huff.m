function y = im2huff(x)
%IM2HUFF Huffman encodes a image matrix.
% Y = IM2HUFF(X) Huffman encodes image matrix X using symbol
% probabilities in unit-width histogram bins.
% Y:
% Y.size The size of X
% Y.gray The gray levels contain in X
% Y.hist The histogram of X
% Y.codlen The Huffman code length
% Y.code The Huffman-encoded values of X, stored in
% a uint16 vector.
%
% Check input argument
if ndims(x) ~= 2 || ~isreal(x) || (~isnumeric(x)&& ~islogical(x))
 error('X must be a 2-D real numeric or logical matrix.');
end
% Store the image dimesion for decopressing
y.size = size(x);
% Compute the probabilities of each gray level
[p,gray]=imhist(x);
% Get rid of the gray levels whose probabilities is zero
indices = find(p);
y.gray = gray(indices);
p = p(indices);
% Normalize the gray level probability
p = p/sum(p);
y.hist = p;
% Construct Huffman codeword using available MATLAB m-function
dict = huffmandict(y.gray,y.hist);
% Reshape image matrix to image vector and encode it
hcode = huffmanenco(reshape(x,1,(y.size(1))*(y.size(2))),dict);
y.codlen = length(hcode); % Huffman code length
ysize = ceil(y.codlen/16); % Compute encode size
hx16 = zeros(1, ysize*16); % Pre-allocate modulo-16 vector
hx16(1:y.codlen) = hcode; % Make hx modulo-16 in length
hx16 = reshape(hx16, 16, ysize); % Reshape to 16-character words
hx16 = hx16';
% Convert binary string to decimal
twos = pow2(15:-1:0);
y.code = (uint16(hx16*twos'));
end