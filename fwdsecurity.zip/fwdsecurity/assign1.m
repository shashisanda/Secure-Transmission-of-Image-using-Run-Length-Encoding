ori_img=imfinfo('lena_gray.bmp')
a=ori_img.FileSize
comp_img=imfinfo('recon3.bmp')
b=comp_img.FileSize
CR=a/b;