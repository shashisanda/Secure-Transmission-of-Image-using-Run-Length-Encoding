ori_img=imfinfo('recon.jpg')
a=ori_img.FileSize
comp_img=imfinfo('recon3.jpg')
b=comp_img.FileSize
CR=a/b;