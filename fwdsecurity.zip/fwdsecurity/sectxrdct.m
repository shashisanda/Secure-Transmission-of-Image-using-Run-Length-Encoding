clc;
clear all;
close all;
img=uigetfile('.jpg','select an image');
img=imread(img);
[row col]=size(img);
input_img=imresize(img,[256 256]);
input_img=im2double(input_img);
gray_img=rgb2gray(input_img);
figure;
subplot(1,2,1);
imshow(input_img);title('original image');
subplot(1,2,2);
imshow(gray_img);title('gray scale image');


%----------------------HyBRID DWT DCT--------------------------------
 T = dctmtx(8);
dct = @(block_struct) T * block_struct.data * T';
B = blockproc(gray_img,[8 8],dct);

mask = [1   1   1   1   0   0   0   0 
        1   1   1   0   0   0   0   0
        1   1   0   0   0   0   0   0
        1   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0];
fun=@(block_struct) mask .* block_struct.data;
Blk_proc_img = blockproc(B,[8 8],fun);
figure;
imshow(Blk_proc_img);
title('block processing');

imwrite(Blk_proc_img,'recon.jpg');
%------------------------------------------------------------------

%Zigzag ordering
zigzag_img=zigzag(Blk_proc_img);

%Encoding
enc_img=rle(zigzag_img);


%Decoding
dec_img=irle(enc_img);

%inverse zigzag
invzigzag_img=invzigzag(dec_img);

%INVERSE DCT
invdct = @(block_struct) T' * block_struct.data * T;
I2 = blockproc(invzigzag_img,[8 8],invdct);
figure;imshow(I2);title('inverse DCT');
figure;
subplot(1,2,1);
imshow(gray_img);title('input image');
imwrite(gray_img,'recon1.jpg');
subplot(1,2,2);
imshow(I2);title('reconstruted image');
imwrite(I2,'recon2.jpg');

%calculation of  MSE
mseimage=(double(gray_img)-double(I2)).^2;
[rows columns]=size(gray_img);
mse=sum(mseimage(:))/(rows*columns);
disp('mse=');
disp(mse);

%calculation of peak signal to noise ratio(PSNR)
psnr_value=10*log10(255^2)-10*log10(mse);
disp('PSNR=');
disp(psnr_value);

%----------------------------------------------------------------------