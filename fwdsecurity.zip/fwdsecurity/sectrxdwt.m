clc;
clear all;
close all;
img=uigetfile('.jpg','select an image');
img=imread(img);
[row col]=size(img);
input_img=imresize(img,[1024 1024]);
input_img=im2double(input_img);
gray_img=rgb2gray(input_img);
figure;
subplot(1,2,1);
imshow(input_img);title('original image');
subplot(1,2,2);
imshow(gray_img);title('gray scale image');
imwrite(gray_img,'recon.jpg');

%------------------- DWT for cover image----------------------------
%1st level
[LL,LH,HL,HH] = dwt2(gray_img,'haar');
a=[LL,LH;HL,HH];
figure;
subplot(1,3,1);
imshow(a);title('1st level');
imwrite(a,'recon1.jpg');
%2nd level
[LL1,LH1,HL1,HH1] = dwt2(LL,'haar');
aa1=[LL1,LH1;HL1,HH1];
subplot(1,3,2);imshow(aa1);title('2nd level');
imwrite(aa1,'recon2.jpg');
%3rd level
[LL2,LH2,HL2,HH2] = dwt2(LL1,'haar');
aa2=[LL2,LH2;HL2,HH2];
subplot(1,3,3);imshow(aa2);title('3rd level');
imwrite(aa2,'recon3.jpg');


%-------------------------------------------------------------------
%%Security%%
% Zigzag ordering
zigzag_img=zigzag(LL2);

%Encoding
enc_img=rle(zigzag_img);

%%Reception%%

%Decoding
dec_img=irle(enc_img);

%inverse zigzag
I2=invzigzag(dec_img);
imwrite(I2,'I2.jpg');


%-----------------INVERSE DWT-----------------------------------------
%1st level idwt
idwt_image1=idwt2(I2 ,LH2, HL2, HH2,'haar');
figure;subplot(1,3,1);
imshow(idwt_image1);title('idwt for 1st level');
imwrite(idwt_image1,'recon7.jpg');
%2nd level idwt
idwt_image2=idwt2(idwt_image1 ,LH1, HL1, HH1,'haar');
subplot(1,3,2);
imshow(idwt_image2);title('idwt for 2nd level');
imwrite(idwt_image2,'recon8.jpg');
idwt_image2=imresize(idwt_image2,[512,512]);
%3rd level idwt
idwt_image3=idwt2(idwt_image2 ,LH, HL, HH,'haar');
subplot(1,3,3);
imshow(idwt_image3);title('idwt for 3rd level');
imwrite(idwt_image3,'recon9.jpg');

%calculation of  MSE
mseimage=(double(gray_img)-double(idwt_image3).^2);
[rows columns]=size(gray_img);
mse=sum(mseimage(:))/(rows*columns);
disp('mse=');
disp(mse);

max_value=max(max(gray_img));
%calculation of peak signal to noise ratio(PSNR)
psnr_value=10*log10(255^2)-10*log10(mse);
disp('PSNR=');
disp(psnr_value);
%----------------------------------------------------------------------
imwrite(enc_img,'enc.gif')
imfinfo('enc.gif')
ori_img=imfinfo('recon3.jpg')
a=ori_img.FileSize
comp_img=imfinfo('enc.gif')
b=comp_img.FileSize
CR=a/b