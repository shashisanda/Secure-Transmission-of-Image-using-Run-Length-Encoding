clear all;
close all;
img=imread('lena_gray.bmp');
figure()
imshow(img);title('Original image');
y=im2huff(img)

%[sim,vfreq]=proba(a2);
%somf=sum(vfreq); %la somme des frequences
%Xfreq=vfreq./somf;
%dict = huffmandict(sim,Xfreq);
%code = huffmanenco(a2,dict);