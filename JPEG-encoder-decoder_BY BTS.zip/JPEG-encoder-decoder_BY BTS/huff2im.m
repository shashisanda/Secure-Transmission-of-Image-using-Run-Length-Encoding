function x = huff2im(y)
% HUFF2MAT decodes a Huffman encoded matrix.
% X = HUFF2MAT(Y) decodes a Huffman encoded structure Y with uint16
% fields:
% Y:
% Y.size The size of original image
% Y.gray The gray levels contain in original image
% Y.hist The histogram of image
% Y.codlen The Huffman code length
% Y.code The Huffman-encoded values, stored in
% a uint16 vector.
%
if ~isstruct(y) || ~isfield(y, 'size') || ~isfield(y, 'gray') || ...
 ~isfield(y, 'hist')|| ~isfield(y, 'codlen')|| ~isfield(y,'code')
 error('The input must be a sructure as returned by IM2HUFF.');
end
% Convert decimal array to binary array for decoding process
hcode = de2bi(y.code,16,'left-msb');
hcode = hcode';
hcode = reshape(hcode,1,[]);
hcode = hcode(1:y.codlen);
hcode = double(hcode);
% Reconstruct Huffman codewords database
dict = huffmandict(y.gray,y.hist);
% Decode the hcode using huffmandeco MATLAB function
dhsig = huffmandeco(hcode,dict);
x = reshape(dhsig,y.size(1),y.size(2));
x = uint8(x);
end
