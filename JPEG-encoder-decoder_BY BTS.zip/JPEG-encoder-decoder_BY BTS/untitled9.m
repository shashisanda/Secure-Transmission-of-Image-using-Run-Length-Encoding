% clearing all variableas screen and 
clear all; 
close all; 
clc; 

% Reading image 
a = imread ( 'lenna-lg.jpg'); 
figure, imshow (a) 

% converting an image to grayscale 
In = rgb2gray (a); 

% size of the image 
[m, n] = size (In); 
TotalCount = m * n; 

% variables using to find the probability 
cnt = 1; 
sigma = 0; 

% computing the cumulative probability. 
for i = 0: 255 
    k = In == i; 
    count (cnt) = sum (k (:)) 

% pro array is having the probabilities 
    pro (cnt) = count (cnt) / TotalCount; 
sigma = sigma + pro (cnt); 
cumpro (cnt) = sigma; 
cnt = cnt + 1; 
end; 


% Symbols for an image 
symbol = [0: 255]; 

% Huffman code dictionary 
dict = huffmandict (symbol, pro); 

% function Which converts array to Vector 
vec_size = 1; 
for p = 1: m 
Q = 1: n 
newvec (vec_size,:) = In(p, Q); 
vec_size = vec_size + 1; 
end 
sig = randsrc(480,1,[symbol;pro]);
% Huffman Encodig 
hcode = huffmanenco (sig, dict) ; 

% Huffman Decoding 
dhsig1 = huffmandeco(hcode, dict); 

isequal(sig,dhsig1)

% convertign dhsig1 double to dhsig uint8 
dhsig = uint8 (dhsig1); 
% vector to array conversion 
dec_row = sqrt (length (dhsig)); 
dec_col = dec_row; 

% variables using to convert vector 2 array 
arr_row = 1; 
arr_col = 1; 
vec_si = 1, 

for x = 1: m
    y = 1: n 
    reverse (x, y) = dhsig (vec_si); 
    arr_col = arr_col + 1; 
    vec_si = vec_si + 1;  
    arr_row = arr_row + 1;
end



% converting the image from grayscale to RGB 
[Deco, map] = gray2ind (reverse, 256); 
RGB = ind2rgb (Deco, map); 
imwrite (RGB, 'decoded.JPG'); 