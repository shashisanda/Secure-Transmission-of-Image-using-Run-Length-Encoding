
%%%%%%%%%%BEHIND THE SCIENCES %%%%%%%%%%

%%%%%%%%%%************JPEG: ENCONDER AND DECODER************%%%%%%%%%
%%%%%%%%%%%DFT%%%%%%%%%
i1=imread('lena_gray.bmp');
I1=fft2(i1);
Ilog=log(abs(I1));
Ishow=mat2gray(fftshift(Ilog));
%%figure()
imshow(Ishow)
colormap(jet),colorbar
mesh(Ishow)

%%%%%%%%DCT%%%%%%%%%%%%

J=dct2(i1);
%%figure()
image(log(abs(J))),colormap(jet),colorbar
i1=uint8(idct2(J));
J(abs(J)<10)=0;
comprimida=idct2(J);
%%figure()
imshow(i1),figure,imshow(comprimida,[0, 255])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DCT COMPUTATION IN JPEG%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
img=imread('lena_gray.bmp');
figure()
imshow(img);title('Original image');

%%%%%%%%We divide the image in 4 blocks%%%%%%%%%%
blocks=cell(2,2);
blocks{1,1}=img(1:256,1:256);
blocks{1,2}=img(1:256,257:512);
blocks{2,1}=img(257:512,1:256);
blocks{2,2}=img(257:512,257:512);

figure()

subplot(2,2,1), imshow(blocks{1,1});title('Image divided in blocks:')
subplot(2,2,2), imshow(blocks{1,2})
subplot(2,2,3), imshow(blocks{2,1})
subplot(2,2,4), imshow(blocks{2,2})


blocks1=(blocks{1,1});
blocks2=(blocks{1,2});
blocks3=(blocks{2,1});
blocks4=(blocks{2,2});

%%%%%%%%%%% We represent the histogram of each block an we calculate the
%%%%%%%%%%% entropy:


%The histogram is a bi-dimensional representation of the relative frequency with which a gray level appears in the image. Therefore, for
%each gray level in the abscissa, we will see the number of pixel that the image has in that gray level; the black colour is represented by zero
%whille the white is one. The histogram at the left side corresponds with the original image while the one in the left corresponds to the 
%differentiate image, there is a great concentration of elements with a gray level close to 0.5 (neutral gray, which has been represented with 
% the zero value). When the image has a well defined statistics, where just a few values are represented with high probability, it's very efficient
% to use variable length codes where the more probable values are represented with less bits. This is the basic idea behind the Huffman
% codes. Note that this codification is lossless, where the diferentiation has a suitable precision. In this example, the original image was coded
% with 256 gray levels (8 bits per sample), so the differenciate signals take values betwee -255 and 255 because a pixel can take a null value
% when the previous was white or vice versa. This means that if we want to recover the original image with the exact gray levels (lossless), we need
% to keep the 511 possible values that the differenciate signal can take (9 bits per sample). If these values are approximated by a less accurate
% quantification, it won't be possible to recover the original image.

figure()
hist1=imhist(blocks1);
subplot(2,2,1),imhist(blocks1);title('Histogram of block 1');
p1=hist1./(size(blocks1,1)*size(blocks1,2));
p1=p1(p1>0);
H1=-sum(p1.*(log2(p1)));
H1(isnan(H1))=0;


%Due to the low sensibility of the human eye for high spatial frequencies,
%we discriminate with a threshold by setting to zero the values below.
%There is a loss information but it doesn't affect to the image quality.

hist2=imhist(blocks2);
p2=hist2./((size(blocks2,1)*size(blocks2,2)));
subplot(2,2,2),imhist(blocks2);title('Histogram of block 2');
p2=p2(p2>0);
H2=-sum(p2.*(log2(p2)));
H2(isnan(H2))=0;



hist3=imhist(blocks3);
subplot(2,2,3),imhist(blocks3);title('Histogram of block 3');
p3=hist3./(size(blocks3,1)*size(blocks3,2));
p3=p3(p3>0);
H3=-sum(p3.*(log2(p3)));
H3(isnan(H3))=0;


hist4=imhist(blocks4);
subplot(2,2,4),imhist(blocks4);title('Histogram of block 4');
p4=hist4./(size(blocks4,1)*size(blocks4,2));
p4=p4(p4>0);
H4=-sum(p4.*(log2(p4)));
H4(isnan(H4))=0;

%%%%%%%%%% We convert the coefficients in to integers %%%%%%%%%%%

blocks1=int16(blocks1);
blocks2=int16(blocks2);
blocks3=int16(blocks3);
blocks4=int16(blocks4);

%%%%%%%% We apply the DCT to each block  %%%%%%%%%%

blocks1=dct2(blocks{1,1});
blocks2=dct2(blocks{1,2});
blocks3=dct2(blocks{2,1});
blocks4=dct2(blocks{2,2});


 

%%%%%%%% We apply the threshold to each block  %%%%%%%%%%


blocks1(abs(blocks1)<10)=0; %%%%threshold=10
% 
blocks2(abs(blocks2)<10)=0; %%%%threshold=10
% 
blocks3(abs(blocks3)<10)=0; %%%%threshold=10
% 
blocks4(abs(blocks4)<10)=0; %%%%threshold=10

%%%%%%%% We display the percentage of coefficients equal to zero%%%%%%

percent1 = length(blocks1(blocks1==0))/(size(blocks1,1)*size(blocks1,2))
percent2 = length(blocks1(blocks2==0))/(size(blocks2,1)*size(blocks2,2))
percent3 = length(blocks1(blocks3==0))/(size(blocks3,1)*size(blocks3,2))
percent4 = length(blocks1(blocks4==0))/(size(blocks4,1)*size(blocks4,2))


%%%%%%%%%%%%%%%%%%%%%%%%%%We represent these coeffiecients%%%%%%%%%%%%%%%%

img2=[blocks1 blocks2; blocks3 blocks4];
img2 = log(abs(double(img2))); %%%%Logarithmic scale

figure()
imshow(img2,[]);title('Quantified DCT coeffients');


%%%%%%%%%%%%%%%%%%%%%%%We compute the IDCT%%%%%%%%%%%%%%%%%%%

block1=uint8(idct2(blocks1));
block2=uint8(idct2(blocks2));
block3=uint8(idct2(blocks3));
block4=uint8(idct2(blocks4));

figure()
img3=[block1 block2; block3 block4];
imshow(img3);title('Decompressed Image');


